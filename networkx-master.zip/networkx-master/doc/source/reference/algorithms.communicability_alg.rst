***************
Communicability
***************

.. automodule:: networkx.algorithms.communicability_alg
.. autosummary::
   :toctree: generated/

   communicability
   communicability_exp
